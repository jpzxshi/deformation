1. run 'generate_3d_domain.py'
2. run 'generate_training_data.py'
3. run 'train_3d_domain.py'