import numpy as np
import pygmsh
import os
from gaussian_process import Gaussian_process_3d
from scipy.interpolate import griddata
from itertools import product
from Poisson_equation_3d_general import poisson
from tools_3d import gen_inner_pts_3d
from plot import plot_3d, plot_mesh_3d, plot_g_3d

def generate_unit_ball():
    with pygmsh.occ.Geometry() as geom:
    #with pygmsh.geo.Geometry() as geom:
        radius = 0.5
        center = [0.5, 0.5, 0.5]
        sphere = geom.add_ball(center, radius, mesh_size=0.1)
        # 生成网格
        mesh = geom.generate_mesh()

    # 提取网格顶点和面
    points = mesh.points
    d = np.linalg.norm(points - center, axis=1)
    index = np.where(d > 0.5 - 0.00000001)
    mesh = {'points': mesh.points,
            'boundary': np.array(index).reshape(-1),
            'line': mesh.cells_dict['line'],
            'triangle': mesh.cells_dict['triangle'],
            'tetra': mesh.cells_dict['tetra']}

    return mesh

def gen_mesh_uniform_3d(n):
    x = np.linspace(0, 1, num=n+1)
    points = np.array(list(product(x, x, x)))
    index_pt = np.arange((n+1) ** 3).reshape(n+1, n+1, n+1)
    cube_rd_0 = index_pt[:n][:,:n][:,:,:n].reshape(-1,1)
    cube_0 = np.concatenate((cube_rd_0, cube_rd_0+1, cube_rd_0+n+2, cube_rd_0 + n+1, cube_rd_0 + (n+1)**2, \
                             cube_rd_0 + (n+1)**2 + 1, cube_rd_0 + (n+1)**2 + n+2, cube_rd_0 + (n+1)**2+n+1), axis=-1)
    tetra1 = np.concatenate((cube_0[:,4].reshape(-1,1), cube_0[:,0].reshape(-1,1), cube_0[:,1].reshape(-1,1), cube_0[:,3].reshape(-1,1)), axis=-1)
    tetra2 = np.concatenate((cube_0[:,4].reshape(-1,1), cube_0[:,5].reshape(-1,1), cube_0[:,1].reshape(-1,1), cube_0[:,6].reshape(-1,1)), axis=-1)
    tetra3 = np.concatenate((cube_0[:, 2].reshape(-1, 1), cube_0[:, 1].reshape(-1, 1), cube_0[:, 6].reshape(-1, 1),
                             cube_0[:, 3].reshape(-1, 1)), axis=-1)
    tetra4 = np.concatenate((cube_0[:, 1].reshape(-1, 1), cube_0[:, 4].reshape(-1, 1), cube_0[:, 6].reshape(-1, 1),
                             cube_0[:, 3].reshape(-1, 1)), axis=-1)
    tetra5 = np.concatenate((cube_0[:, 7].reshape(-1, 1), cube_0[:, 3].reshape(-1, 1), cube_0[:, 6].reshape(-1, 1),
                             cube_0[:, 4].reshape(-1, 1)), axis=-1)
    tetras = np.concatenate((tetra1, tetra2, tetra3, tetra4, tetra5), axis=0)
    vertex = np.array([[0,0,0],[0,1,0],[0,0,1],[0,1,1],
                       [1,0,0],[1,1,0],[1,0,1],[1,1,1]])
    cond1 = points[:,0] == 0
    cond2 = points[:,1] == 0
    cond3 = points[:,2] == 0
    cond4 = points[:,0] == 1
    cond5 = points[:,1] == 1
    cond6 = points[:,2] == 1
    b_index = np.hstack((np.array(np.where(cond1)), np.array(np.where(cond2)), np.array(np.where(cond3)),\
                         np.array(np.where(cond4)), np.array(np.where(cond5)), np.array(np.where(cond6)))).reshape(-1)
    b_index = list(set(b_index.tolist()))
    b_index = np.array(b_index).reshape(-1)
    mesh = {
        'points': points,
        'vertex': vertex,
        'tetra' : tetras,
        'boundary': b_index
    }
    return mesh

def func_inter_3d(func, pts, m):
    x = np.linspace(0,1,m)
    points = np.array(list(product(x, x, x)))
    value = func.reshape(-1)
    f_inter = griddata(points, value, pts, method='linear')
    return f_inter

def generate_data(n):
    # generate n datapoints
    
    # size of uniform mesh is m ** 3
    m = 10 # 20

    # generate standard_ball_mesh
    mesh_ball = generate_unit_ball()

    # generate mesh_uniform
    mesh_uniform = gen_mesh_uniform_3d(m-1)

    # generate area
    ####
    gp_area = Gaussian_process_3d([[0, 1]] * 3, 1, 0.1, 0.2, m)
    #gp_area = Gaussian_process_3d([[0, 1]] * 3, 1, 0.05, 0.2, m) # paper version!!!!!
    ####
    area_ratio_uniform = gp_area.generate(n)
    points = mesh_ball['points']
    boundary_index = mesh_ball['boundary']
    b = boundary_index[-1]+1
    boundary_pts = points[boundary_index].reshape(-1,3)
    areas = []
    for i in range(n):
        ratioi = area_ratio_uniform[i]
        ratioi_pt = func_inter_3d(ratioi, boundary_pts, m).reshape(-1,1)
        ####
        center = np.array([0.5, 0.5, 0.5])
        areai = (boundary_pts - center) * ratioi_pt + center
        #areai = boundary_pts * ratioi_pt # paper version!!!!!
        ####
        areas.append(areai)

    # generate mesh points
    mesh_points = []
    for i in range(n):
        poly = areas[i]
        ptsi_inner = gen_inner_pts_3d(boundary_pts, mesh_ball['triangle'], points[b:], areas[i]).reshape(-1,3)
        ptsi = np.concatenate((poly, ptsi_inner), axis=0)
        mesh_points.append(ptsi)

    # generate random function
    gpk = Gaussian_process_3d([[0, 1]] * 3, 1, 0.2, 0.2, m)
    k = gpk.generate(n)  # [n, m, m, m]
    gpf = Gaussian_process_3d([[0, 1]] * 3, 0, 1, 0.2, m)
    f = gpf.generate(n)  # [n, m, m, m]

    # interpolation
    k_mesh = []
    f_mesh = []
    for i in range(n):
        k_mesh.append(func_inter_3d(k[i], points, m))
        f_mesh.append(func_inter_3d(f[i], points, m))

    # solve
    solutions = []
    b_uniform = mesh_uniform['boundary']
    g = np.zeros(b_uniform.shape[0])
    for i in range(n):
        print('Solving PDE No. {} ...'.format(i), flush=True)
        solutions.append(poisson(mesh_uniform['tetra'], mesh_uniform['points'], b_uniform, f[i].reshape(-1), g, k[i].reshape(-1)))

    # generate g,u
    g_mesh = []
    u_mesh = []
    for i in range(n):
        g_mesh.append(func_inter_3d(solutions[i], boundary_pts, m))
        u_mesh.append(func_inter_3d(solutions[i], points, m))

    # data
    data = {}
    data['num'] = n
    for i in range(n):
        data['points_{}'.format(i)] = mesh_points[i]
        data['vertex'] = mesh_ball['boundary']
        data['tetra'] = mesh_ball['tetra']
        data['triangle'] = mesh_ball['triangle']
        data['k_{}'.format(i)] = k_mesh[i]
        data['f_{}'.format(i)] = f_mesh[i]
        data['g_{}'.format(i)] = g_mesh[i]
        data['u_{}'.format(i)] = u_mesh[i]

    return data

def plot(data):
    n = 0
    # plot
    mesh = {}
    mesh['points'] = data['points_{}'.format(n)]
    mesh['vertex'] = data['vertex']
    mesh['triangle'] = data['triangle']

    points = data['points_{}'.format(n)]
    k = data['k_{}'.format(n)]
    f = data['f_{}'.format(n)]
    g = data['g_{}'.format(n)]
    u = data['u_{}'.format(n)]

    plot_mesh_3d(mesh)
    plot_g_3d(mesh, g)
    plot_3d(points, k)
    plot_3d(points, f)
    plot_3d(points, u)

def save_data(data):
    save_dir = 'data/3d_domains'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    np.savez_compressed('data/3d_domains/3d_domain_data.npz', **data)
    data = np.load('data/3d_domains/3d_domain_data.npz')
    #print(data.files)
    print('vertex', data['vertex'].shape, data['vertex'].dtype)
    print('tetra', data['tetra'].shape, data['tetra'].dtype)
    print('triangle', data['triangle'].shape, data['triangle'].dtype)
    for i in range(min(data['num'], 2)):
        print('points_{}'.format(i), data['points_{}'.format(i)].shape, data['points_{}'.format(i)].dtype)
        print('k_{}'.format(i), data['k_{}'.format(i)].shape, data['k_{}'.format(i)].dtype)
        print('f_{}'.format(i), data['f_{}'.format(i)].shape, data['f_{}'.format(i)].dtype)
        print('g_{}'.format(i), data['g_{}'.format(i)].shape, data['g_{}'.format(i)].dtype)
        print('u_{}'.format(i), data['u_{}'.format(i)].shape, data['u_{}'.format(i)].dtype)


def main():
    data = generate_data(4100) # 5000
    save_data(data)
    #plot(data)

if __name__ == '__main__':
    main()

