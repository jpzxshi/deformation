import numpy as np
from tools_3d import ball_surface, gen_inner_pts_3d, gen_boundary_pts_direction, ball, gen_inner_pts_ball_3d
from solve_interpolation_3d import solve_inter
import os

def domain_3d_data(n_train, n_test):
    num_sensor = 2000
    boundary_sensor = 1000

    raw_data = np.load('data/3d_domains/3d_domain_data.npz')
    surface_sample = ball_surface(boundary_sensor)
    ball_sample = ball(num_sensor)
    boundary_sample = []
    f = []
    g = []
    k = []
    y = []
    tetra = raw_data['tetra']
    vertex = raw_data['vertex']
    tri = raw_data['triangle']
    for i in range(n_train + n_test):
        print('Processing No. {} ...'.format(i), flush=True)
        points = raw_data['points_{}'.format(i)]
        poly = points[vertex].reshape(-1, 3)
        #pts_b = points[vertex].reshape(-1, 3)
        random_pts = gen_inner_pts_ball_3d(tri, ball_sample, poly).reshape(-1,3)
        # boundary sample
        center = np.array([0.5,0.5,0.5])
        direction = surface_sample - center
        bi = gen_boundary_pts_direction(poly, tri, center, direction)
        boundary_sample.append(np.linalg.norm(bi, axis=1, keepdims=True))
        # f, k, y sample
        fi = solve_inter(raw_data['f_{}'.format(i)], points, tetra, random_pts)
        ki = solve_inter(raw_data['k_{}'.format(i)], points, tetra, random_pts)
        yi = solve_inter(raw_data['u_{}'.format(i)], points, tetra, random_pts)
        f.append(fi)
        k.append(ki)
        y.append(yi)
        # g sample
        gi = solve_inter(raw_data['u_{}'.format(i)], points, tetra, bi)
        g.append(gi)
    boundary_sample = np.array(boundary_sample).reshape(n_train + n_test, boundary_sensor)
    f = np.array(f).reshape(n_train + n_test, num_sensor)
    k = np.array(k).reshape(n_train + n_test, num_sensor)
    y = np.array(y).reshape(n_train + n_test, num_sensor)
    g = np.array(g).reshape(n_train + n_test, boundary_sensor)

    fg = np.concatenate((f, g), axis=-1)
    x_train = (boundary_sample[:n_train], fg[:n_train], k[:n_train], ball_sample)
    x_test = (boundary_sample[-n_test:], fg[-n_test:], k[-n_test:], ball_sample)
    y_train = y[:n_train]
    y_test = y[-n_test:]

    save_dir = 'data/3d_domains'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    np.savez_compressed('data/3d_domains/X_train', *x_train)
    np.savez_compressed('data/3d_domains/X_test', *x_test)
    np.save('data/3d_domains/y_train', y_train)
    np.save('data/3d_domains/y_test', y_test)
    np.save('data/3d_domains/ball_sample', ball_sample)

def main():
    domain_3d_data(4000,100) # 4000, 1000/100

if __name__ == '__main__':
    main()