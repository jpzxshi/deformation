import learner as ln
#import torch


class Poisson_varying_domains_data(ln.data.Data_MIONet_Cartesian):
    '''Data for 2d Poisson equation defined on varying domains.
    '''

    def __init__(self, path):
        super(Poisson_varying_domains_data, self).__init__()
        import numpy as np
        X_train, X_test = np.load(path + '/X_train.npz'), np.load(path + '/X_test.npz')
        self.X_train = (X_train['arr_0'], X_train['arr_1'], X_train['arr_2'], X_train['arr_3'])
        self.y_train = np.load(path + '/y_train.npy')
        self.X_test = (X_test['arr_0'], X_test['arr_1'], X_test['arr_2'] , X_test['arr_3'])
        self.y_test = np.load(path + '/y_test.npy')


def postprocessing(data, net, loss_history):
    #### post processing, for example, plot a figure if needed.
    plot(data, net)

def plot(data, net):
    import matplotlib.pyplot as plt
    from tools_3d import surface_2_ball
    import numpy as np
    from matplotlib import cm

    n = 0

    raw_data = np.load('data/3d_domains/3d_domain_data.npz')
    X_test = data.X_test
    y_test = data.y_test
    n_train = data.X_train_np[0].shape[0]
    boundary = X_test[0][n]
    fg = X_test[1][n]
    k = X_test[2][n]
    points = raw_data['points_{}'.format(n_train + n)]
    poly = points[raw_data['vertex']].reshape(-1, 3)
    tri = raw_data['triangle']
    X = surface_2_ball(poly)
    surface_pre = net.predict((boundary, fg, k, X), returnnp=True).reshape(-1)
    y_true = raw_data['u_{}'.format(n_train + n)]
    surface_true = y_true[raw_data['vertex']]

    value_true = []
    value_pre = []
    for index in tri:
        value_true.append(np.mean(surface_true[index]))
        value_pre.append(np.mean(surface_pre[index]))
    value_true = np.array(value_true)
    value_pre = np.array(value_pre)
    rela_true = (value_true - np.min(value_true)) / (np.max(value_true) - np.min(value_true))
    rela_pre = (value_pre - np.min(value_pre)) / (np.max(value_pre) - np.min(value_pre))
    cmap = cm.viridis
    colors_true = cmap(rela_true)
    colors_pre = cmap(rela_pre)
    norm_true = cm.colors.Normalize(vmin=np.min(value_true), vmax=np.max(value_true))
    norm_pre = cm.colors.Normalize(vmin=np.min(value_pre), vmax=np.max(value_pre))

    fig = plt.figure(figsize=(20, 8))
    titlesize = 18

    ax0 = fig.add_subplot(1, 2, 1, projection='3d')
    ax0.set_title('Ground truth', size=titlesize)
    surf0 = ax0.plot_trisurf(poly[:, 0], poly[:, 1], poly[:, 2], triangles=tri)
    surf0.set_facecolors(colors_true)
    cbar = plt.colorbar(cm.ScalarMappable(norm=norm_true, cmap=cmap), ax=ax0)

    ax1 = fig.add_subplot(1, 2, 2, projection='3d')
    ax1.set_title('Prediction', size=titlesize)
    surf1 = ax1.plot_trisurf(poly[:, 0], poly[:, 1], poly[:, 2], triangles=tri)
    surf1.set_facecolors(colors_pre)
    cbar = plt.colorbar(cm.ScalarMappable(norm=norm_pre, cmap=cmap), ax=ax1)

    plt.savefig("prediction.pdf")
    plt.show()


def main():
    #### device
    device = 'gpu'  # 'cpu' or 'gpu'
    #### data
    path = 'data/3d_domains'# the directory of the dataset
    #### MIONet
    sizes = [
        [1000] + [500] * 4 + [1000],
        [3000, -1000], # -500 means the last layer is without bias
        [2000] + [500] * 4 + [1000],
        [3] + [500] * 4 + [1000],
    ]
    activation = 'relu'
    #### training
    lr = 1e-6
    iterations = 5000000 # 5000000
    batch_size = 10
    print_every = 1000

    training_args = {
        'criterion': 'MSE',
        'optimizer': 'Adam',
        'lr': lr,
        'iterations': iterations,
        'batch_size': batch_size,
        'print_every': print_every,
        'save': 'best_only',
        'callback': None,
        'dtype': 'float',
        'device': device,
    }

    ln.Brain.Start()
    data = Poisson_varying_domains_data(path)
    net = ln.nn.MIONet_Cartesian(sizes, activation, bias=False)
    ln.Brain.Init(data, net)
    ln.Brain.Run(**training_args)
    ln.Brain.Restore()
    ln.Brain.Output(data=False)
    postprocessing(data, ln.Brain.Best_model(), ln.Brain.Loss_history())
    ln.Brain.End()


if __name__ == '__main__':
    main()