#import matplotlib.pyplot as plt
import numpy as np

def del_repeat(index):
    l = len(index)
    new = [index[0]]
    for i in range(1,l):
        a = index[i]
        b = index[i-1]
        if a[0] != b[0]:
            new.append(index[i])
    return new

def tetra_inner_mumlti_cali(solve_pts, tetra_index, pts):
    A = solve_pts[tetra_index[:, 0]]
    B = solve_pts[tetra_index[:, 1]]
    C = solve_pts[tetra_index[:, 2]]
    D = solve_pts[tetra_index[:, 3]]
    # compute 4 triangles: s1:BCD, s2: ACD, s3: ABD, s4: ABC
    d = np.ones((A.shape[0], 4, 1))
    D0 = np.concatenate((solve_pts[tetra_index], d), axis=-1)
    D0 = np.repeat(D0.reshape(1, A.shape[0], 4, 4), pts.shape[0], axis=0)
    d_pt = np.concatenate((pts, np.ones((pts.shape[0], 1))), axis=-1).reshape(pts.shape[0], 1, 1, 4)
    d_pt = np.repeat(d_pt, A.shape[0], axis=1)

    D1 = D0.copy()
    D1[:, :, 0] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D2 = D0.copy()
    D2[:, :, 1] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D3 = D0.copy()
    D3[:, :, 2] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D4 = D0.copy()
    D4[:, :, 3] = d_pt.reshape(pts.shape[0], A.shape[0], 4)

    v0 = np.linalg.det(D0)
    v1 = np.linalg.det(D1)
    v2 = np.linalg.det(D2)
    v3 = np.linalg.det(D3)
    v4 = np.linalg.det(D4)

    sign0 = np.sign(v0)
    v0_s = (v0 * sign0)
    v1_s = (v1 * sign0)
    v2_s = (v2 * sign0)
    v3_s = (v3 * sign0)
    v4_s = (v4 * sign0)
    cond1 = v0_s >= 0
    cond2 = v1_s >= 0
    cond3 = v2_s >= 0
    cond4 = v3_s >= 0
    cond5 = v4_s >= 0
    index = np.where((cond1 & cond2 & cond3 & cond4 & cond5))
    index = np.array(index).T
    index_count = index[:, 0].tolist()
    index_wrong = []
    for i in range(pts.shape[0]):
        if i not in index_count:
            index_wrong.append(i)
    for i in index_wrong:
        pti = pts[i]
        tetras = solve_pts[tetra_index]
        diff = tetras - pti
        d = diff[:,:,0]**2 + diff[:,:,1]**2 + diff[:,:,2]**2
        d = d[:,0] + d[:,1] + d[:,2] + d[:,3]
        min = np.min(d)
        index_i = np.where(d == min)
        index_i = np.array(index_i)[0][0]
        rowi = np.array([i, index_i])
        index = np.insert(index, i, np.array([i, index_i]), axis=0)
    index_count = index[:, 0].tolist()
    index = index.tolist()
    if len(index_count) != len(set(index_count)):
        index = del_repeat(index)
    index = np.array(index)
    return index[:, 1]

def tetra_inner_mumlti(solve_pts, tetra_index, pts):
    '''
    pts: N * 3 array
    index: M * 4 array
    return array t*1 of index of tetra
    pt: t*3 array
    '''
    A = solve_pts[tetra_index[:, 0]]
    B = solve_pts[tetra_index[:, 1]]
    C = solve_pts[tetra_index[:, 2]]
    D = solve_pts[tetra_index[:, 3]]
    # compute 4 triangles: s1:BCD, s2: ACD, s3: ABD, s4: ABC
    d = np.ones((A.shape[0],4,1))
    D0 = np.concatenate((solve_pts[tetra_index], d), axis=-1)
    D0 = np.repeat(D0.reshape(1, A.shape[0], 4, 4), pts.shape[0], axis=0)
    d_pt = np.concatenate((pts, np.ones((pts.shape[0],1))), axis=-1).reshape(pts.shape[0], 1, 1, 4)
    d_pt = np.repeat(d_pt, A.shape[0], axis=1)

    D1 = D0.copy()
    D1[:,:,0] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D2 = D0.copy()
    D2[:, :, 1] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D3 = D0.copy()
    D3[:, :, 2] = d_pt.reshape(pts.shape[0], A.shape[0], 4)
    D4 = D0.copy()
    D4[:, :, 3] = d_pt.reshape(pts.shape[0], A.shape[0], 4)

    v0 = np.linalg.det(D0)
    v1 = np.linalg.det(D1)
    v2 = np.linalg.det(D2)
    v3 = np.linalg.det(D3)
    v4 = np.linalg.det(D4)

    sign0 = np.sign(v0)
    v0_s = (v0 * sign0)
    v1_s = (v1 * sign0)
    v2_s = (v2 * sign0)
    v3_s = (v3 * sign0)
    v4_s = (v4 * sign0)
    cond1 = v0_s >= 0
    cond2 = v1_s >= 0
    cond3 = v2_s >= 0
    cond4 = v3_s >= 0
    cond5 = v4_s >= 0
    index = np.where((cond1 & cond2 & cond3 & cond4 & cond5))
    index = np.array(index).T
    index_count = index[:, 0].tolist()
    index = index.tolist()
    if len(index_count) != len(set(index_count)):
        index = del_repeat(index)
    index = np.array(index)
    return index[:,1]

def solve_inter(solve, solve_pts, solve_tetra_index ,pts):
    index_inter = tetra_inner_mumlti_cali(solve_pts, solve_tetra_index, pts)
    if len(index_inter) == 0:
        return False
    elif len(index_inter) != pts.shape[0]:
        return False
    else:
        tetra_inter = solve_tetra_index[index_inter]
        index_A = tetra_inter[:, 0]
        index_B = tetra_inter[:, 1]
        index_C = tetra_inter[:, 2]
        index_D = tetra_inter[:, 3]
        X_a, Y_a, Z_a = solve_pts[index_A][:, 0], solve_pts[index_A][:, 1], solve_pts[index_A][:, 2]
        X_b, Y_b, Z_b = solve_pts[index_B][:, 0], solve_pts[index_B][:, 1], solve_pts[index_B][:, 2]
        X_c, Y_c, Z_c = solve_pts[index_C][:, 0], solve_pts[index_C][:, 1], solve_pts[index_C][:, 2]
        X_d, Y_d, Z_d = solve_pts[index_D][:, 0], solve_pts[index_D][:, 1], solve_pts[index_D][:, 2]

        M_a = np.array([[X_a - X_d, X_b - X_d, X_c - X_d],
                        [Y_a - Y_d, Y_b - Y_d, Y_c - Y_d],
                        [Z_a - Z_d, Z_b - Z_d, Z_c - Z_d]]).transpose(2,0,1)
        b = -np.array([[X_d - pts[:,0]],[Y_d - pts[:,1]],[Z_d - pts[:,2]]]).transpose(2,0,1)
        s = np.linalg.solve(M_a, b).reshape(pts.shape[0], 3)
        u = s[:,0].reshape(-1,1) * solve[index_A].reshape(-1,1) + s[:,1].reshape(-1,1) * solve[index_B].reshape(-1,1)\
            + s[:,2].reshape(-1,1) * solve[index_C].reshape(-1,1) + (1-s[:,0] - s[:,1] - s[:,2]).reshape(-1,1) * solve[index_D].reshape(-1,1)
        return u.reshape(-1)


def main():
    solve_pts = np.load('data/3d_2/mesh_points.npy')
    mesh = np.load('data/3d_2/meshes.npz')
    solve = np.load('data/3d_2/solve_mesh.npy')
    tetra = mesh['tetra']
    tetras = np.repeat(tetra.reshape(1, -1, 4), 4100, axis=0)
    pts = np.load('data/3d_2/random_inner_pts.npy')
    u = solve_inter(solve, solve_pts, tetras, pts)
    np.save('data/3d_2/solve_random', u)

if __name__ == '__main__':
    main()