import numpy as np
#import matplotlib.pyplot as plt
# Solve Possion equation  - k Delta u = f ,  partial u = g  for 3d regions

def A_e_general(pts, tetra, ij, k):
    i = ij[0]
    j = ij[1]
    index_i = tetra.index(i)
    index_j = tetra.index(j)
    b_i = np.zeros((4))
    b_j = np.zeros((4))
    b_i[index_i] = 1
    b_j[index_j] = 1
    A = pts[tetra]
    c_1 = np.ones((4, 1))
    A = np.concatenate((A, c_1), axis=-1)
    a_i = np.linalg.solve(A, b_i)  # coefficients
    a_j = np.linalg.solve(A, b_j)

    a_k = np.linalg.solve(A, k[tetra])
    x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3= A[0][0], A[0][1], A[0][2], A[1][0], A[1][1], A[1][2], A[2][0], A[2][1], A[2][2], A[3][0], A[3][1], A[3][2]
    int_x = (x1 - x0) / 24 + (x2 - x0) / 24 + (x3 - x0) / 24 + x0 / 6
    int_y = (y1 - y0) / 24 + (y2 - y0) / 24 + (y3 - y0) / 24 + y0 / 6
    int_z = (z1 - z0) / 24 + (z2 - z0) / 24 + (z3 - z0) / 24 + z0 / 6
    J = np.array([[x1 - x0, x2 - x0, x3 - x0],
                  [y1 - y0, y2 - y0, y3 - y0],
                  [z1 - z0, z2 - z0, z3 - z0]])
    det_J = np.abs(np.linalg.det(J))
    int_x = det_J * int_x
    int_y = det_J * int_y
    int_z = det_J * int_z
    return np.dot(a_i[:3], a_j[:3]) * np.abs(np.linalg.det(A)) / 6 * a_k[-1] + np.dot(a_i[:3], a_j[:3]) * int_x * a_k[0] \
    + np.dot(a_i[:3], a_j[:3]) * int_y * a_k[1] + np.dot(a_i[:3], a_j[:3]) * int_z * a_k[2]


def A_e(pts, tetra, ij):
    # pts: vertices
    # tetra: index of tetra
    i = ij[0]
    j = ij[1]
    index_i = tetra.index(i)
    index_j = tetra.index(j)
    b_i = np.zeros((4))
    b_j = np.zeros((4))
    b_i[index_i] = 1
    b_j[index_j] = 1
    A = pts[tetra]
    c_1 = np.ones((4,1))
    A = np.concatenate((A, c_1), axis=-1)
    a_i = np.linalg.solve(A, b_i)  # coefficients
    a_j = np.linalg.solve(A, b_j)
    return np.dot(a_i[:3], a_j[:3]) * np.abs(np.linalg.det(A)) / 6

def b_e(pts,tetra, i, f):
    # take vertices of element and return contribution to b
    index_i = tetra.index(i)
    b_i = np.zeros((4))
    b_i[index_i] = 1
    b = np.array([f[tetra[0]], f[tetra[1]], f[tetra[2]], f[tetra[3]]])
    A = pts[tetra]
    c_1 = np.ones((4, 1))
    A = np.concatenate((A, c_1), axis=-1)
    s_i = np.linalg.solve(A, b_i)
    s = np.linalg.solve(A, b)
    a_i, b_i, c_i, d_i = s_i[0], s_i[1], s_i[2], s_i[3]
    a, b, c, d = s[0], s[1], s[2], s[3]
    x0, y0, z0, x1, y1, z1, x2, y2 ,z2, x3, y3, z3 = A[0][0], A[0][1], A[0][2], A[1][0], A[1][1], A[1][2], A[2][0], A[2][1], A[2][2], A[3][0], A[3][1], A[3][2]
    J = np.array([[x1 - x0, x2 - x0, x3 - x0],
                  [y1 - y0, y2 - y0, y3 - y0],
                  [z1 - z0, z2 - z0, z3 - z0]])
    int_x2 = (x1-x0)**2/60 + (x2-x0)**2/60 + (x3-x0)**2/60 + (x1-x0)*(x2-x0)/60 + (x1-x0)*(x3-x0)/60 \
            + (x2-x0)*(x3-x0)/60 + x0*(x1-x0)/12 + x0*(x2-x0)/12 + x0*(x3-x0)/12 + x0**2/6
    int_y2 = (y1-y0)**2/60 + (y2-y0)**2/60 + (y3-y0)**2/60 + (y1-y0)*(y2-y0)/60 + (y1-y0)*(y3-y0)/60 \
            + (y2-y0)*(y3-y0)/60 + y0*(y1-y0)/12 + y0*(y2-y0)/12 + y0*(y3-y0)/12 + y0**2/6
    int_z2 = (z1-z0)**2/60 + (z2-z0)**2/60 + (z3-z0)**2/60 + (z1-z0)*(z2-z0)/60 + (z1-z0)*(z3-z0)/60 \
            + (z2-z0)*(z3-z0)/60 + z0*(z1-z0)/12 + z0*(z2-z0)/12 + z0*(z3-z0)/12 + z0**2/6
    int_xy = (x1-x0)*(y1-y0)/60 + (x2-x0)*(y2-y0)/60 + (x3-x0)*(y3-y0)/60 + (x1-x0)*(y2-y0)/120 + (x1-x0)*(y3-y0)/120 \
            + (x2-x0)*(y1-y0)/120 + (x2-x0)*(y3-y0)/120 + (x3-x0)*(y1-y0)/120 + (x3-x0)*(y2-y0)/120 + x0*(y1-y0)/24\
            + x0*(y2-y0)/24 + x0*(y3-y0)/24 + y0*(x1-x0)/24 + y0*(x2-x0)/24 + y0*(x3-x0)/24 + x0*y0/6
    int_xz = (x1-x0)*(z1-z0)/60 + (x2-x0)*(z2-z0)/60 + (x3-x0)*(z3-z0)/60 + (x1-x0)*(z2-z0)/120 + (x1-x0)*(z3-z0)/120 \
            + (x2-x0)*(z1-z0)/120 + (x2-x0)*(z3-z0)/120 + (x3-x0)*(z1-z0)/120 + (x3-x0)*(z2-z0)/120 + x0*(z1-z0)/24\
            + x0*(z2-z0)/24 + x0*(z3-z0)/24 + z0*(x1-x0)/24 + z0*(x2-x0)/24 + z0*(x3-x0)/24 + x0*z0/6
    int_yz = (y1-y0)*(z1-z0)/60 + (y2-y0)*(z2-z0)/60 + (y3-y0)*(z3-z0)/60 + (y1-y0)*(z2-z0)/120 + (y1-y0)*(z3-z0)/120 \
            + (y2-y0)*(z1-z0)/120 + (y2-y0)*(z3-z0)/120 + (y3-y0)*(z1-z0)/120 + (y3-y0)*(z2-z0)/120 + y0*(z1-z0)/24\
            + y0*(z2-z0)/24 + y0*(z3-z0)/24 + z0*(y1-y0)/24 + z0*(y2-y0)/24 + z0*(y3-y0)/24 + y0*z0/6
    int_x = (x1-x0)/24 + (x2-x0)/24 + (x3-x0)/24 + x0/6
    int_y = (y1-y0)/24 + (y2-y0)/24 + (y3-y0)/24 + y0/6
    int_z = (z1-z0)/24 + (z2-z0)/24 + (z3-z0)/24 + z0/6
    int_1 = 1/6
    ans = a_i * a * int_x2 + b_i * b * int_y2 + c_i * c * int_z2 + (a_i * b + b_i * a) * int_xy \
        + (a_i * c + c_i * a) * int_xz + (b_i * c + c_i * b) * int_yz + (a_i * d + d_i * a) * int_x \
        + (b_i * d + d_i * b) * int_y + (c_i * d + d_i * c) * int_z + d * d_i * int_1
    ans = ans * np.abs(np.linalg.det(J))
    return ans

def poisson(tetras, points, boundary, f, g, k):
    N = points.shape[0]
    boundary = boundary.reshape(-1)
    A = np.zeros((N, N))
    b = np.zeros((N))
    g_e = np.zeros((N))
    boundary_list = boundary.tolist()
    for tetra in tetras:
        tetra_list = tetra.tolist()
        l = len(tetra_list)  # l = 4
        index_d = []  # [[element_list[0], element_list[0]], [element_list[0], element_list[1]]...]
        for i in range(l):
            a = tetra[i]
            b[a] = b[a] + b_e(points, tetra_list, a, f)
            for j in range(i,l):
                index_d.append([tetra_list[i], tetra_list[j]])

            if a in boundary_list:
                index_a = boundary_list.index(a)
                a_2 = tetra_list[(i+1)%4]
                a_3 = tetra_list[(i+2)%4]
                a_4 = tetra_list[(i+3)%4]
                if a_2 not in boundary_list:
                    g_e[a_2] += g[index_a]*A_e_general(points, tetra_list, np.array([a, a_2]), k)
                if a_3 not in boundary_list:
                    g_e[a_3] += g[index_a]*A_e_general(points, tetra_list, np.array([a, a_3]), k)
                if a_4 not in boundary_list:
                    g_e[a_4] += g[index_a]*A_e_general(points, tetra_list, np.array([a, a_4]), k)

        for ij in index_d:
            A[ij[0], ij[1]] = A[ij[0], ij[1]] + A_e_general(points, tetra_list, ij, k)


    A = A + np.triu(A, k=1).T + np.tril(A, k=-1).T
    # Delete the boundary rows and columns of A and b here
    b = b - g_e
    A = np.delete(A, boundary, axis=0)
    A = np.delete(A, boundary, axis=1)
    b = np.delete(b, boundary, axis=0)
    # solve for the interior points
    u_init = np.linalg.solve(A, b)
    # restore the whole solution u including the zero boundary points
    u = np.zeros(N)
    u[np.delete(np.arange(N), boundary, axis=0)] = u_init
    u[boundary] = g
    return u  # u.shape = (N,)

def poisson_withoutk(tetras, points, boundary, f, g):
    N = points.shape[0]
    boundary = boundary.reshape(-1)
    A = np.zeros((N, N))
    b = np.zeros((N))
    g_e = np.zeros((N))
    boundary_list = boundary.tolist()
    for tetra in tetras:
        tetra_list = tetra.tolist()
        l = len(tetra_list)  # l = 4
        index_d = []  # [[element_list[0], element_list[0]], [element_list[0], element_list[1]]...]
        for i in range(l):
            a = tetra[i]
            b[a] = b[a] + b_e(points, tetra_list, a, f)
            for j in range(i,l):
                index_d.append([tetra_list[i], tetra_list[j]])

            if a in boundary_list:
                index_a = boundary_list.index(a)
                a_2 = tetra_list[(i+1)%4]
                a_3 = tetra_list[(i+2)%4]
                a_4 = tetra_list[(i+3)%4]
                if a_2 not in boundary_list:
                    g_e[a_2] += g[index_a]*A_e(points, tetra_list, np.array([a, a_2]))
                if a_3 not in boundary_list:
                    g_e[a_3] += g[index_a]*A_e(points, tetra_list, np.array([a, a_3]))
                if a_4 not in boundary_list:
                    g_e[a_4] += g[index_a]*A_e(points, tetra_list, np.array([a, a_4]))

        for ij in index_d:
            A[ij[0], ij[1]] = A[ij[0], ij[1]] + A_e(points, tetra_list, ij)


    A = A + np.triu(A, k=1).T + np.tril(A, k=-1).T
    # Delete the boundary rows and columns of A and b here
    b = b - g_e
    A = np.delete(A, boundary, axis=0)
    A = np.delete(A, boundary, axis=1)
    b = np.delete(b, boundary, axis=0)
    # solve for the interior points
    u_init = np.linalg.solve(A, b)
    # restore the whole solution u including the zero boundary points
    u = np.zeros(N)
    u[np.delete(np.arange(N), boundary, axis=0)] = u_init
    u[boundary] = g
    return u  # u.shape = (N,)

def main():

    meshes = np.load('../generatedata/data/3d/mesh_uniform.npz')
    i = np.random.randint(4100)
    pts = meshes['points']
    f = np.load('../generatedata/data/3d/mesh_f.npy')[i].reshape(-1)
    g = np.zeros_like(meshes['boundary'])
    k = np.load('../generatedata/data/3d/mesh_k.npy')[i].reshape(-1)
    u = poisson(meshes['tetra'], meshes['points'], meshes['boundary'], f, g, k)


if __name__ == '__main__':
    main()