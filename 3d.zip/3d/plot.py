"""
@author: Pengzhan Jin (jpz@pku.edu.cn)
"""
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib import cm

def plot_mesh(mesh):
    points = mesh['points']
    vertex = mesh['vertex'] # vertexes of (100-)polygon
    line = mesh['line'] # boundary lines of mesh (not polygon)
    triangle = mesh['triangle']
    
    vertex_points = points[vertex[:, 0]] 

    print(points.shape)
    #print(points)
    print(vertex.shape)
    #print(vertex)
    print(line.shape)
    #print(line)
    print(triangle.shape)
    #print(triangle)
    
    triangulation = mtri.Triangulation(points[:, 0], points[:, 1], triangle)
    fig, ax = plt.subplots()
    ax.triplot(triangulation, color='black', linewidth=0.5)
    plt.scatter(vertex_points[:, 0], vertex_points[:, 1], s=3)
    plt.title('mesh')
    plt.savefig('mesh.pdf')
    plt.show()
    
def plot_k(mesh, k):
    points = mesh['points']
    triangle = mesh['triangle']
    
    print(points.shape)
    print(triangle.shape)
    print(k.shape)
    
    triangulation = mtri.Triangulation(points[:, 0], points[:, 1], triangle)
    fig, ax = plt.subplots()
    tpc = ax.tripcolor(triangulation, k.ravel(), shading ='gouraud', cmap='rainbow')
    fig.colorbar(tpc)
    plt.title('k')
    plt.savefig('k.pdf')
    plt.show()
    
def plot_f(mesh, f):
    points = mesh['points']
    triangle = mesh['triangle']
    
    print(points.shape)
    print(triangle.shape)
    print(f.shape)
    
    triangulation = mtri.Triangulation(points[:, 0], points[:, 1], triangle)
    fig, ax = plt.subplots()
    tpc = ax.tripcolor(triangulation, f.ravel(), shading ='gouraud', cmap='rainbow')
    fig.colorbar(tpc)
    plt.title('f')
    plt.savefig('f.pdf')
    plt.show()
    
def plot_g(mesh, g):
    points = mesh['points']
    line = mesh['line']
    line_points = points[line[:, 0]]
    
    print(line.shape)
    print(g.shape)
    
    plt.scatter(line_points[:, 0], line_points[:, 1], c=g, cmap='rainbow')
    plt.colorbar()
    plt.title('g')
    plt.savefig('g.pdf')
    plt.show()
    
def plot_u(mesh, u):
    points = mesh['points']
    triangle = mesh['triangle']
    
    print(points.shape)
    print(triangle.shape)
    print(u.shape)
    
    triangulation = mtri.Triangulation(points[:, 0], points[:, 1], triangle)
    fig, ax = plt.subplots()
    tpc = ax.tripcolor(triangulation, u.ravel(), shading ='gouraud', cmap='rainbow')
    fig.colorbar(tpc)
    plt.title('u')
    plt.savefig('u.pdf')
    plt.show()

def plot_3d(points, f):

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    scatter = ax.scatter(points[:,0], points[:,1], points[:,2], c=f, cmap='rainbow', s=100)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    plt.colorbar(scatter)
    plt.show()

def plot_mesh_3d(mesh):
    points = mesh['points']

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_trisurf(points[:, 0], points[:, 1], points[:, 2], triangles=mesh['triangle'])
    plt.title('mesh')
    plt.savefig('mesh.pdf')
    plt.show()

def plot_g_3d(mesh, g):
    import numpy as np
    points = mesh['points']
    tri = mesh['triangle']
    value = []
    for index in tri:
        value.append(np.mean(g[index]))
    value = np.array(value)
    rela = (value - np.min(value)) / (np.max(value) - np.min(value))
    cmap = cm.viridis
    colors_g = cmap(rela)
    norm_true = cm.colors.Normalize(vmin=np.min(value), vmax=np.max(value))

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    surf = ax.plot_trisurf(points[:, 0], points[:, 1], points[:, 2], triangles=tri)
    surf.set_facecolors(colors_g)

    cbar = plt.colorbar(cm.ScalarMappable(norm=norm_true, cmap=cmap), ax=ax)

    plt.title('g')
    plt.savefig('g.pdf')
    plt.show()

def main():
    pass

if __name__ == '__main__':
    main()