import numpy as np


def del_repeat(index):
    l = len(index)
    new = [index[0]]
    for i in range(1,l):
        a = index[i]
        b = index[i-1]
        if a[0] != b[0]:
            new.append(index[i])
    return new

def gen_boundary_pts_3d(poly, face_index, pts):
    pts = pts.reshape(-1,3)
    center = np.mean(poly, axis=0)
    faces = poly[face_index].reshape(-1, 3, 3)
    face_d = np.linalg.det(faces)
    a = (faces[:, 1] - faces[:, 0]).reshape(1, -1, 3, 1)
    b = (faces[:, 2] - faces[:, 0]).reshape(1, -1, 3, 1)
    c = (center - pts).reshape(-1, 1, 3, 1)
    d = -(faces[:, 0] - center).reshape(1, -1, 3, 1)
    a = np.repeat(a, pts.shape[0], axis=0)
    b = np.repeat(b, pts.shape[0], axis=0)
    c = np.repeat(c, faces.shape[0], axis=1)
    d = np.repeat(d, pts.shape[0], axis=0)
    D = np.linalg.det(np.concatenate((a, b, c), axis=-1))
    Da = np.linalg.det(np.concatenate((d, b, c), axis=-1))
    Db = np.linalg.det(np.concatenate((a, d, c), axis=-1))
    Dc = np.linalg.det(np.concatenate((a, b, d), axis=-1))
    u = Da / D
    v = Db / D
    t = Dc / D
    cond1 = u >= 0
    cond2 = v >= 0
    cond3 = t >= 0
    cond4 = u + v <= 1
    index = np.where((cond1 & cond2 & cond3 & cond4))
    index = np.array(index).T
    index_count = index[:,0].tolist()
    index = index.tolist()
    if len(index_count) != len(set(index_count)):
        index = del_repeat(index)
    pts_b = []
    for t in index:
        u_inter = u[t[0]][t[1]]
        v_inter = v[t[0]][t[1]]
        tri = faces[t[1]]
        pt = (1 - u_inter - v_inter) * tri[0] + u_inter * tri[1] + v_inter * tri[2]
        pts_b.append(pt)
    if len(pts_b) != pts.shape[0]:
        print('Points Not match')
    return np.array(pts_b)

def gen_boundary_pts_direction(poly, face_index, center, direction):
    faces = poly[face_index].reshape(-1, 3, 3)
    face_d = np.linalg.det(faces)
    a = (faces[:, 1] - faces[:, 0]).reshape(1, -1, 3, 1)
    b = (faces[:, 2] - faces[:, 0]).reshape(1, -1, 3, 1)
    c = direction.reshape(-1, 1, 3, 1)
    d = -(faces[:, 0] - center).reshape(1, -1, 3, 1)
    a = np.repeat(a, direction.shape[0], axis=0)
    b = np.repeat(b, direction.shape[0], axis=0)
    c = np.repeat(c, faces.shape[0], axis=1)
    d = np.repeat(d, direction.shape[0], axis=0)
    D = np.linalg.det(np.concatenate((a, b, c), axis=-1))
    Da = np.linalg.det(np.concatenate((d, b, c), axis=-1))
    Db = np.linalg.det(np.concatenate((a, d, c), axis=-1))
    Dc = np.linalg.det(np.concatenate((a, b, d), axis=-1))
    u = Da / D
    v = Db / D
    t = Dc / D
    cond1 = u >= 0
    cond2 = v >= 0
    cond3 = t >= 0
    cond4 = u + v <= 1
    index = np.where((cond1 & cond2 & cond3 & cond4))
    index = np.array(index).T
    index_count = index[:, 0].tolist()
    index = index.tolist()
    if len(index_count) != len(set(index_count)):
        index = del_repeat(index)
    pts = []
    for t in index:
        u_inter = u[t[0]][t[1]]
        v_inter = v[t[0]][t[1]]
        tri = faces[t[1]]
        pt = (1 - u_inter - v_inter) * tri[0] + u_inter * tri[1] + v_inter * tri[2]
        pts.append(pt)
    if len(pts) != direction.shape[0]:
        print('Points Not match')
    return np.array(pts)

def gen_inner_pts_3d(poly_uniform, face_index, pts_unirform, poly_target):
    pts = pts_unirform.reshape(-1, 3)
    center = np.mean(poly_uniform, axis=0)
    direction = center - pts
    r_uniform = np.linalg.norm(gen_boundary_pts_3d(poly_uniform, face_index, pts) - center, axis=1)
    b_pts = gen_boundary_pts_direction(poly_target, face_index, np.mean(poly_target, axis=0), direction)
    b_r = np.linalg.norm(b_pts - np.mean(poly_target, axis=0), axis=1)
    inner_pt = (b_r.reshape(-1,1))/ (r_uniform.reshape(-1,1)) * (pts - center) + np.mean(poly_target, axis=0)
    return inner_pt.reshape(1, -1,3)

def gen_inner_pts_ball_3d(face_index, pts_uniform, poly_target):
    pts = pts_uniform.reshape(-1, 3)
    center = np.array([0.5,0.5,0.5])
    direction = center - pts
    pts_r = np.linalg.norm(pts - center, axis=1)
    b_pts = gen_boundary_pts_direction(poly_target, face_index, np.mean(poly_target, axis=0), direction)
    r_uniform = 0.5 * np.ones_like(pts_r)
    t = pts_r.reshape(-1, 1)/(r_uniform.reshape(-1, 1))
    inner_pt = t * (b_pts - np.mean(poly_target, axis=0)) + np.mean(poly_target, axis=0)
    return inner_pt.reshape(1, -1, 3)

def area_2_ball(face_index, pts_unirform, poly_target, ball):
    pts = pts_unirform.reshape(-1, 3)
    center = np.mean(poly_target, axis=0)
    direction = center - pts
    pts_r = np.linalg.norm(pts - center, axis=1).reshape(-1, 1)
    b_pts = gen_boundary_pts_direction(poly_target, face_index, np.mean(poly_target, axis=0), direction)
    bpts_r = np.linalg.norm(b_pts - center, axis=1)
    t = pts_r/bpts_r.reshape(-1, 1)
    direction_r = np.linalg.norm(direction, axis=1, keepdims=True)
    d_norm = direction/direction_r
    ball_pts = np.array([0.5,0.5,0.5]) + d_norm/0.5
    #ball_pts = gen_boundary_pts_direction(ball, face_index, np.array([0.5,0.5,0.5]), direction)
    inner_pt = t * (ball_pts - np.array([0.5,0.5,0.5])) + np.array([0.5,0.5,0.5])
    return inner_pt.reshape(1, -1, 3)

def surface_2_ball(pts):
    pts = pts.reshape(-1, 3)
    center = np.array([0.5, 0.5, 0.5])
    direction = pts - center
    direction_r = np.linalg.norm(direction, axis=1, keepdims=True)
    ball_pts = center + direction / direction_r * 0.5
    return ball_pts.reshape(-1,3)

def ball_surface(n):

    t = np.linspace(0, n, n+1)[:-1]
    phi = (np.sqrt(5) - 1)/2

    z = 1 - 2 * t/(n-1)
    x = np.sqrt(1-z**2) * np.cos(2 * np.pi * t * phi)
    y = np.sqrt(1-z**2) * np.sin(2 * np.pi * t * phi)
    xy = np.concatenate((x.reshape(-1,1),y.reshape(-1,1),z.reshape(-1,1) ), axis=-1)

    return xy

def ball(n):
    cx, cy, cz = 0.5, 0.5, 0.5

    directions = np.random.randn(n, 3)
    norms = np.linalg.norm(directions, axis=1, keepdims=True)
    unit_directions = directions / norms

    radius = 0.5
    u = np.random.uniform(0, 1, n)
    r = radius * np.cbrt(u)

    offset_vectors = unit_directions * r.reshape(-1, 1)

    points = np.array([cx, cy, cz]) + offset_vectors

    return points